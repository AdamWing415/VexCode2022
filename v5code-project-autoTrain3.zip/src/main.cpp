/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\sebachun262                                      */
/*    Created:      Wed Mar 30 2022                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller
// frontArm             motor_group   11, 12
// backArms             motor_group   13, 14
// Drivetrain           drivetrain    2, 1, 4, 3, 10
// Distance             distance      9
// Distance2            distance      18
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
inertial Inertial =
    inertial(PORT10); // have to chek and see if this breaks anything
// Contacting at least one (1) of the gray foam field tiles directly in front of
// their Alliance Station, i.e. the row of gray foam field tiles that contains
// their Alliance’s Platform DON'T HAVE TO START TOUCHING THE WALL

using namespace vex;

int fullArm = 625;

void auto2() { // remeber that goals are reversed ie. blue on red side ALSO,
               // need timer cutoff?
  Drivetrain.setHeading(0, degrees);
  frontArm.spinFor(reverse, fullArm, degrees);

  Drivetrain.setDriveVelocity(60, percent);

  // picks up goal on ramp
  while (true) {
    if (Distance.objectDistance(mm) > 120) {
      Drivetrain.drive(forward);

    } else {
      Drivetrain.stop();
      frontArm.spinFor(forward, 500, degrees); // need hold code
      break;
    }
    Controller1.Screen.clearScreen();
    Controller1.Screen.setCursor(1, 1);
    Controller1.Screen.print(Distance.objectDistance(mm));
  }
  // navigate around the ramp
  Drivetrain.turnToHeading(270, degrees);
  Drivetrain.driveFor(forward, 20, inches); //                                       WHOLE Block, needs
               //                                       testing !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  frontArm.spinFor(reverse, 500, degrees);
  Drivetrain.turnToHeading(0, degrees);

  Drivetrain.setDriveVelocity(100, percent);
  Drivetrain.setHeading(0, degrees);

  Drivetrain.driveFor(forward, 60, inches);

  // Gets second goal
  while (true) {

    if (Distance.objectDistance(mm) > 600) {
      Drivetrain.drive(forward);
    } else if (600 > Distance.objectDistance(mm) &&
               Distance.objectDistance(mm) > 120) {
      Drivetrain.setDriveVelocity(60, percent);
      Drivetrain.drive(forward);
    } else {
      Drivetrain.stop();
      frontArm.spinFor(reverse, 250, degrees);
      break;
    }
  }
  // now drivetrain needs to be backwards
  Drivetrain.setDriveVelocity(75, percent);
  Drivetrain.driveFor(reverse, 10, inches); // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  backArms.spinFor(forward, fullArm, degrees);

  Drivetrain.turnToHeading(90, degrees);

  // picks up third goal
  while (true) {
    if (Distance2.objectDistance(mm) >
        120) { // needs us to add new distance sensor to other side
      Drivetrain.drive(reverse);

    } else {
      Drivetrain.stop();
      backArms.spinFor(forward, 250, degrees); // need hold code
      break;
    }
  }

  // sets down third goal to grab fourth off of ramp
  for (int i = 0; i <= 135; i++) { // Not sure if this is best option, should
                                   // check that this is in the scoring zone
    Drivetrain.driveFor(reverse, 10, mm);
    Drivetrain.turnFor(right, 1, degrees); //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  }

  Drivetrain.turnToHeading(270, degrees);

  // orients us with the team wall
  while (true) {
    if (Distance.objectDistance(mm) > 200) {
      Drivetrain.drive(forward);

    } else {
      Drivetrain.stop();
      break;
    }
  }

  Drivetrain.turnToHeading(180, degrees);

  Drivetrain.setDriveVelocity(100, percent);
  Drivetrain.driveFor(forward, 24, inches);//                  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

  while (true) {
    Drivetrain.setDriveVelocity(85, percent);

    if (Inertial.orientation(pitch, degrees) >
        15) { // uses IMU reading to see when it starts to tip, check angle of
              // elevation for this
      Drivetrain.drive(forward);
    } else if (Inertial.orientation(pitch, degrees) <
               -5) { // probably need too tweak this to get it to actaully stop
                     // on top
      Drivetrain.drive(reverse);
    } else {
      Drivetrain.stop();
      break;
    }
  }
}

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  frontArm.setStopping(hold);
  backArms.setStopping(hold);

  if (Controller1.ButtonA.pressing()) {
    auto2();
  }
}
